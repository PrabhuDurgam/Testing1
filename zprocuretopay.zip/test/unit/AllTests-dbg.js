sap.ui.define([
	"com/ptp/zProcureToPay/test/unit/controller/Home.controller"
], function () {
	"use strict";
});