sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	
	"use strict";

	return Controller.extend("com.ptp.zProcureToPay.controller.Home", {
		onInit: function () {
			var model = this.getOwnerComponent().getModel().getData();
			console.log(model);
			var headerModel = new sap.ui.model.json.JSONModel()
			this.getView().setModel(headerModel,'headerModel');
		},
		
		// sortTable: function()
		
		dataSelected: function(evt){
			debugger;
			var dataObj = evt.getParameter('data');
			var docType = dataObj["0"].data["PO Document Type"];
			var table = this.getView().byId('container-zProcureToPay---Home--tableId');
			var items = table.getBinding('items');
			var oFilter = new sap.ui.model.Filter('PO Document type', sap.ui.model.FilterOperator.EQ, docType);
			items.filter(oFilter);
		
		},
		
		closeDialog: function(){
			this.filterFragment.close();
		},
		
		filterMenuPress: function(evt){
				if(!this.filterFragment){
					this.filterFragment = sap.ui.xmlfragment("ToolbarFilter", "com.ptp.zProcureToPay.ext.Filter", this);
					this.getView().addDependent(this.filterFragment);
				}
				this.filterFragment.open();
		},
		
		showValueHelp: function(evt){
			var dialog = new sap.m.TableSelectDialog({
					contentHeight: '400px',
					contentWidth: '400px',
					title:evt.getSource().getPlaceholder(),
					columns: [
						new sap.m.Column({header: new sap.m.Text({text:evt.getSource().getPlaceholder()})}),
						new sap.m.Column({header: new sap.m.Text({text:'Description'})})
					]
			});
			
			dialog.open();
		},
		
		onAfterRendering: function(){
			debugger;
			console.log(this.getView().getAggregation('content')[0].getAggregation('app').getAggregation('pages')[0].getAggregation('content')[4].getAggregation('content'));
			var vizframe = this.getView().getAggregation('content')[0].getAggregation('app').getAggregation('pages')[0].getAggregation('content')[4].getAggregation('content')[0];
			var vizframe2 = this.getView().getAggregation('content')[0].getAggregation('app').getAggregation('pages')[0].getAggregation('content')[4].getAggregation('content')[1];
			// mAggregations.content[""0""].mAggregations.app.mAggregations.pages[""0""].mAggregations.content[3].mAggregations.items[""0""].mAggregations.content
			// var vizframe = this.getView().byId('idVizFrame');
			// var vizframe2 = this.getView().byId('idVizFrame2');
			vizframe.setVizProperties({
				
					plotArea: {
						colorPalette : ["#5bbae7","#b6da58","#f9c463","#935dd0","#008000","#800000"],
						dataLabel: {
							visible: true,
							showTotal: true,
							type : 'value'
						},
						title: {
							visible: true,
							text:'Doc Type distribution'
						},
						valueAxis:{
							axisLine: {
								visible: true
								
							}
						}
						
					}
				});
			vizframe2.setVizProperties({
					plotArea: {
						colorPalette:["#808080"],
						dataLabel: {
							visible: true,
							showTotal: true,
							type : 'value'
							// formatString: chartFormatFunction
						},
						title: {
							visible: true,
							text:'Doc Type distribution'
						},
						valueAxis:{
							axisLine: {
								visible: true
								
							}
						}
					}
				});	
			debugger;
			var vizPopover = new sap.viz.ui5.controls.Popover({});
			vizPopover.connect(vizframe.getVizUid());
			  //var oChartContainerContent = new sap.suite.ui.commons.ChartContainerContent({
     //               icon : "sap-icon://horizontal-bar-chart",
     //               title : "vizFrame Bar Chart Sample",
     //               content : [ vizframe ]
     //           });
                
     //           var oChartContainer = new sap.suite.ui.commons.ChartContainer({
     //               content : [ oChartContainerContent ]
     //           });
                
     //           oChartContainer.setShowFullScreen(true);
     //           oChartContainer.setAutoAdjustHeight(true);
     //           oChartContainer.setShowZoom(false);
				
		}
	});
});