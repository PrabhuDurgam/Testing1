sap.ui.define(["sap/ui/core/mvc/Controller"], function (e) {
	"use strict";
	return e.extend("com.ptp.zProcureToPay.controller.Home", {
		onInit: function () {
			var e = this.getOwnerComponent().getModel().getData();
			console.log("model - ",e);
			var t = new sap.ui.model.json.JSONModel;
			this.getView().setModel(t, "headerModel")
		},
		dataSelected: function (e) {
			debugger;
			var t = e.getParameter("data");
			var i = t["0"].data["PO Document Type"];
			var o = this.getView().byId("container-zProcureToPay---Home--tableId");
			var n = o.getBinding("items");
			var g = new sap.ui.model.Filter("PO Document type", sap.ui.model.FilterOperator.EQ, i);
			n.filter(g)
		},
		closeDialog: function () {
			this.filterFragment.close()
		},
		filterMenuPress: function (e) {
			if (!this.filterFragment) {
				this.filterFragment = sap.ui.xmlfragment("ToolbarFilter", "com.ptp.zProcureToPay.ext.Filter", this);
				this.getView().addDependent(this.filterFragment)
			}
			this.filterFragment.open()
		},
		showValueHelp: function (e) {
			var t = new sap.m.TableSelectDialog({
				contentHeight: "400px",
				contentWidth: "400px",
				title: e.getSource().getPlaceholder(),
				columns: [new sap.m.Column({
					header: new sap.m.Text({
						text: e.getSource().getPlaceholder()
					})
				}), new sap.m.Column({
					header: new sap.m.Text({
						text: "Description"
					})
				})]
			});
			t.open()
		},
		onAfterRendering: function () {
			debugger;
			console.log("aaa - ",this.getView().getAggregation("content")[0].getAggregation("app").getAggregation("pages")[0].getAggregation("content")[
				4].getAggregation("content"));
			var e = this.getView().getAggregation("content")[0].getAggregation("app").getAggregation("pages")[0].getAggregation("content")[4].getAggregation(
				"content")[0];
			var t = this.getView().getAggregation("content")[0].getAggregation("app").getAggregation("pages")[0].getAggregation("content")[4].getAggregation(
				"content")[1];
			e.setVizProperties({
				plotArea: {
					colorPalette: ["#5bbae7", "#b6da58", "#f9c463", "#935dd0", "#008000", "#800000"],
					dataLabel: {
						visible: true,
						showTotal: true,
						type: "value"
					},
					title: {
						visible: true,
						text: "Doc Type distribution"
					},
					valueAxis: {
						axisLine: {
							visible: true
						}
					}
				}
			});
			t.setVizProperties({
				plotArea: {
					colorPalette: ["#808080"],
					dataLabel: {
						visible: true,
						showTotal: true,
						type: "value"
					},
					title: {
						visible: true,
						text: "Doc Type distribution"
					},
					valueAxis: {
						axisLine: {
							visible: true
						}
					}
				}
			});
			debugger;
			var i = new sap.viz.ui5.controls.Popover({});
			i.connect(e.getVizUid())
		}
	})
});